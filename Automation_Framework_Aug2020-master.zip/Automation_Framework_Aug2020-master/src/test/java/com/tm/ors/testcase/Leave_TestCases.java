package com.tm.ors.testcase;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.tm.framework.BaseTestClass;
import com.tm.framework.ExcelLib;
import com.tm.ors.screenpages.Home;
import com.tm.ors.screenpages.Login;

public class Leave_TestCases extends BaseTestClass {
	
	//=======================================================================
	@Test
	void tc001_VerifyLoginAuthentication()
	{		
		//get test data of current test case from test data file(Excel)
		String filepath = TESTDATA_PATH + TESTDATA_FILE;
		//String[] data = Excel.getRowData(filepath, "smoke", CURRENT_TESTCASE);
		HashMap<String, String> data = ExcelLib.getRowData2(filepath, "ORS", CURRENT_TESTCASE);
		
		//initialize elements of required pages
		Login login = PageFactory.initElements(driver, Login.class);				
		Home home = PageFactory.initElements(driver, Home.class);
		
		//Step 1: Verify login page displayed with elements
		login.pageDisplayed();
		login.loginPageElements();
				
		//Step 2: Login as a team member with valid data and verify home page displayed
		login.loginAPP(data.get("user"), data.get("pwd"));		
		home.pageDisplayed();
	}
	
	//=======================================================================
	@Test
	void tc002_ApplyLeave()
	{			
		//get test data of current test case from test data file(Excel)
		String filepath = TESTDATA_PATH + TESTDATA_FILE;
		//String[] data = Excel.getRowData(filepath, "smoke", CURRENT_TESTCASE);
		HashMap<String, String> data = ExcelLib.getRowData2(filepath, "ORS", CURRENT_TESTCASE);
				
		// initialize elements of required pages
		Login login = PageFactory.initElements(driver, Login.class);
		Home home = PageFactory.initElements(driver, Home.class);
		//ApplyLeave applyleave = PageFactory.initElements(driver, ApplyLeave.class);
		
		//Test case steps
		login.pageDisplayed();
		login.loginAPP(data.get("user"), data.get("pwd"));
		home.pageDisplayed();
		//applyLeave(data[2], data[3], data[4], data[5]);		
	}
	//=======================================================================	
	
	@Test
	void tc003_cancelleave()
	{			
		System.out.println("Test case 3");	
	}
	
}
