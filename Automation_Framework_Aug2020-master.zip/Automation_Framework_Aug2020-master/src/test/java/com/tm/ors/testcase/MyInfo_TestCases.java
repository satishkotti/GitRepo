package com.tm.ors.testcase;

import com.tm.framework.BaseTestClass;

public class MyInfo_TestCases extends BaseTestClass {
	
	
	
	
	

}
